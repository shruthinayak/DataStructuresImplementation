
/**
 * Created by shruthi on 19/3/16.
 */
public interface ShortestPath {

    int INF = Integer.MAX_VALUE;

    void getShortestPath();

    int getTotalOfShortestPaths();

    String getName();
}
